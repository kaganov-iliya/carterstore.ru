﻿Для Maxystore 2.0.3.1 чтобы появился пункт Поставщики в меню, нужно: 

В файл
admin/controller/maxystore/menu.php
После строки:

                $data['text_manufacturer'] = $this->language->get('text_manufacturer');

Добавить:

                $data["text_suppler"] = $this->language->get("text_suppler");  /*suppler*/

После строки:

                $data['marketing'] = $this->url->link('marketing/marketing', 'token=' . $this->session->data['token'], 'SSL');

Добавить:

                $data["suppler"] = $this->url->link("catalog/suppler", "token=" . $this->session->data["token"], "SSL");  /*suppler*/

В файл
view/template/maxystore/common/menu.tpl
После строки:

      <li><a href="<?php echo $manufacturer; ?>"><?php echo $text_manufacturer; ?></a></li>

Добавить:

      <li><a href="<?php echo $suppler; ?>"><?php echo $text_suppler; ?></a></li> <!--*suppler*-->

После этого зайти в Дополнения\Модификации и нажать Обновить.