﻿В этой папке хранятся образцы прайсов, которые я загрузил на демо:

http://ann.8bits.com.ua/admin     ( demo  demo )
http://zrada.8bits.com.ua/admin   ( demo  demo )
http://check.8bits.com.ua/admin   ( demo  demo )
http://8bits.com.ua/admin         ( demo  demo )

Обратите внимание на Создание категорий, это прайсы: "сырой" и "исправленный".