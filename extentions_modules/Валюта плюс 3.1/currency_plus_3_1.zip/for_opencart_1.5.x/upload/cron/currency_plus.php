<?php
require_once('../config.php');

file_get_contents(HTTPS_SERVER."index.php?route=wgi/currency_plus&type=all");
?>