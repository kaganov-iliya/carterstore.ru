<?php
$_['text_search'] = 'Поиск:';
$_['text_choose_region'] = 'Выберите город';
$_['text_search_placeholder'] = 'Введите название города';
$_['text_your_city'] = 'Ваш город';
$_['text_guessed'] = 'Угадали?';
$_['text_unknown'] = 'Не определено';
