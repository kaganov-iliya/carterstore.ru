<?php
$_['text_search'] = 'Search:';
$_['text_choose_region'] = 'Select a city';
$_['text_search_placeholder'] = 'Enter city name';
$_['text_your_city'] = 'Your city';
$_['text_guessed'] = 'Guessed?';
$_['text_unknown'] = 'Undefined';
