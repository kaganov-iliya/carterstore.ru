/**
 * @author Larionov Alexandr
 * @link   http://larionov.me
 */

function getImgLoaderAjax() {
	var ajaxLoaderImg = document.createElement("img");
	ajaxLoaderImg.setAttribute(
		'src',
		'data:image/png;base64,R0lGODlhEAAQAPQAAP///0CLsvP3+afJ2+fw9XSqxpvC1kCLsoGyzFqbvMDY5c7h6k6Ut7TR4EKMs2ijwo260QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAAFdyAgAgIJIeWoAkRCCMdBkKtIHIngyMKsErPBYbADpkSCwhDmQCBethRB6Vj4kFCkQPG4IlWDgrNRIwnO4UKBXDufzQvDMaoSDBgFb886MiQadgNABAokfCwzBA8LCg0Egl8jAggGAA1kBIA1BAYzlyILczULC2UhACH5BAkKAAAALAAAAAAQABAAAAV2ICACAmlAZTmOREEIyUEQjLKKxPHADhEvqxlgcGgkGI1DYSVAIAWMx+lwSKkICJ0QsHi9RgKBwnVTiRQQgwF4I4UFDQQEwi6/3YSGWRRmjhEETAJfIgMFCnAKM0KDV4EEEAQLiF18TAYNXDaSe3x6mjidN1s3IQAh+QQJCgAAACwAAAAAEAAQAAAFeCAgAgLZDGU5jgRECEUiCI+yioSDwDJyLKsXoHFQxBSHAoAAFBhqtMJg8DgQBgfrEsJAEAg4YhZIEiwgKtHiMBgtpg3wbUZXGO7kOb1MUKRFMysCChAoggJCIg0GC2aNe4gqQldfL4l/Ag1AXySJgn5LcoE3QXI3IQAh+QQJCgAAACwAAAAAEAAQAAAFdiAgAgLZNGU5joQhCEjxIssqEo8bC9BRjy9Ag7GILQ4QEoE0gBAEBcOpcBA0DoxSK/e8LRIHn+i1cK0IyKdg0VAoljYIg+GgnRrwVS/8IAkICyosBIQpBAMoKy9dImxPhS+GKkFrkX+TigtLlIyKXUF+NjagNiEAIfkECQoAAAAsAAAAABAAEAAABWwgIAICaRhlOY4EIgjH8R7LKhKHGwsMvb4AAy3WODBIBBKCsYA9TjuhDNDKEVSERezQEL0WrhXucRUQGuik7bFlngzqVW9LMl9XWvLdjFaJtDFqZ1cEZUB0dUgvL3dgP4WJZn4jkomWNpSTIyEAIfkECQoAAAAsAAAAABAAEAAABX4gIAICuSxlOY6CIgiD8RrEKgqGOwxwUrMlAoSwIzAGpJpgoSDAGifDY5kopBYDlEpAQBwevxfBtRIUGi8xwWkDNBCIwmC9Vq0aiQQDQuK+VgQPDXV9hCJjBwcFYU5pLwwHXQcMKSmNLQcIAExlbH8JBwttaX0ABAcNbWVbKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICSRBlOY7CIghN8zbEKsKoIjdFzZaEgUBHKChMJtRwcWpAWoWnifm6ESAMhO8lQK0EEAV3rFopIBCEcGwDKAqPh4HUrY4ICHH1dSoTFgcHUiZjBhAJB2AHDykpKAwHAwdzf19KkASIPl9cDgcnDkdtNwiMJCshACH5BAkKAAAALAAAAAAQABAAAAV3ICACAkkQZTmOAiosiyAoxCq+KPxCNVsSMRgBsiClWrLTSWFoIQZHl6pleBh6suxKMIhlvzbAwkBWfFWrBQTxNLq2RG2yhSUkDs2b63AYDAoJXAcFRwADeAkJDX0AQCsEfAQMDAIPBz0rCgcxky0JRWE1AmwpKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICKZzkqJ4nQZxLqZKv4NqNLKK2/Q4Ek4lFXChsg5ypJjs1II3gEDUSRInEGYAw6B6zM4JhrDAtEosVkLUtHA7RHaHAGJQEjsODcEg0FBAFVgkQJQ1pAwcDDw8KcFtSInwJAowCCA6RIwqZAgkPNgVpWndjdyohACH5BAkKAAAALAAAAAAQABAAAAV5ICACAimc5KieLEuUKvm2xAKLqDCfC2GaO9eL0LABWTiBYmA06W6kHgvCqEJiAIJiu3gcvgUsscHUERm+kaCxyxa+zRPk0SgJEgfIvbAdIAQLCAYlCj4DBw0IBQsMCjIqBAcPAooCBg9pKgsJLwUFOhCZKyQDA3YqIQAh+QQJCgAAACwAAAAAEAAQAAAFdSAgAgIpnOSonmxbqiThCrJKEHFbo8JxDDOZYFFb+A41E4H4OhkOipXwBElYITDAckFEOBgMQ3arkMkUBdxIUGZpEb7kaQBRlASPg0FQQHAbEEMGDSVEAA1QBhAED1E0NgwFAooCDWljaQIQCE5qMHcNhCkjIQAh+QQJCgAAACwAAAAAEAAQAAAFeSAgAgIpnOSoLgxxvqgKLEcCC65KEAByKK8cSpA4DAiHQ/DkKhGKh4ZCtCyZGo6F6iYYPAqFgYy02xkSaLEMV34tELyRYNEsCQyHlvWkGCzsPgMCEAY7Cg04Uk48LAsDhRA8MVQPEF0GAgqYYwSRlycNcWskCkApIyEAOwAAAAAAAAAAAA==');
		ajaxLoaderImg.setAttribute('alt', 'ajaxLoader');
		return ajaxLoaderImg;
		//document.body.appendChild(ajaxLoaderImg);
}

function showMessage(result) {
	var text = this[String(result)] || result;
	var className;

	if(result === 'success_saved')
		className = 'success fa fa-check-circle';
	else if(result === 'error_saved')
		className = 'warning fa fa-exclamation-circle';
	else
		className = 'info fa fa-info-circle';

	$('.note_block_static').length && $('.note_block_static').remove();
	$('#container').append('<div class="note_block_static ' + className + '">' + text + '</div>');

	$('.note_block_static').fadeIn('400', function() {
		setTimeout(function() {
			$('.note_block_static').fadeOut('400');
		}, 5000);
	});
	return true;
}

function renderErrorsSaved(response) {
	$('.text-danger').remove();
	$('.has-error').removeClass('has-error');

	return (response.length != 0) &&
	showMessage('error_saved') &&
	$.each(response, function(index, value) {
		
		var input_rospost = $("[name='shipping_rospost_" + index + "']");
		var input_rospost_array = $("[name^='shipping_rospost_" + index + "['][type='text']");

		if(input_rospost.length) {
			input_rospost.parent().closest(':not(.input-group)').append('<div class="error text-danger">' + value + '</div>');
			input_rospost.parent().parent().addClass('has-error');
		}
		else if(input_rospost_array.length) {
			var list = input_rospost_array.closest('.well, .scrollbox');
			if(list.length) {
				input_rospost_array.closest('.well, .scrollbox').parent().append('<div class="error text-danger">' + value + '</div>');
				input_rospost_array.closest('.col-sm-10').parent().addClass('has-error');
			} else {
				input_rospost_array.parent().append('<div class="text-danger error">' + value + '</div>');
				input_rospost_array.parent().parent().addClass('has-error');
			}
			
		}
	}) || showMessage('success_saved');
}

function saveStayAjax(e) {
	$.ajax({
		type: 'post',
		dataType: 'json',
		url: $("#form, form[id*='form-']:not([id*='form-upload'])").attr('action') + '&save=&stay=1',
		data: $("#form, form[id*='form-']").serialize(),
		beforeSend: function() {
			$("#form, form[id*='form-']:not([id*='form-upload'])").fadeTo('slow', 0.5);
		},
		complete: function() {
			$("#form, form[id*='form-']:not([id*='form-upload'])").fadeTo('slow', 1);   
		},
		success: function(response) {
			renderErrorsSaved(response);
		},
		error: function(xhr, ajaxOptions, thrownError) {
			ajaxRequestOnError(xhr, thrownError);
		}
	});
	$.isFunction(e.preventDefault) && e.preventDefault();
}

// get stat, test, log
function get_data(target, file, idate, errorlog, obj) {

	var data = (file ? 'logfile=' + file : '');
	data += (idate ? 'date=' + idate : '');
	data += (errorlog ? '&errorlog=' + errorlog : '');
	$.ajax({
		url: 'index.php?route=' + pathFilesModule + '/get_data&target=' + target + '&' + var_token + '=' + token,
		dataType: 'json',
		type: 'get',
		data: data,
		beforeSend: function(jqXHR, settings) {
			$('#' + target).siblings('.ajximg').append(getImgLoaderAjax());
		},
		complete: function() {
			$('#' + target).siblings('.ajximg').empty();
		},
		success: function(json) {
			if(json.error) {
				$('#' + target).empty().html('<div class="error" style="word-wrap: break-word;">' + json.error + '</div>');
			}
			else {
				if(target == 'stat') {
					if(v2) {
					var html = '<table class="table table-striped table-hover table-condensed" style="width: 70%;"><tr><th>Дата</th><th>Запросов</th><th>Ср.время</th><th>Ср.размер</th><th>Ошибки</th></tr>';
					} else {
					var html = '<table class="form" style="width: 70%;"><tr><th style="text-align: center;">Дата</th><th style="text-align: center;">Запросов</th><th style="text-align: center;">Ср.время</th><th style="text-align: center;">Ср.размер</th><th style="text-align: center;">Ошибки</th></tr>';
					}

					$.each(json['data'], function(index, value) {
						html += '<tr><td colspan="5"><h2><a class="log" href="#" data-date="' + value.month + '">' + value.month + '</a></h2></td></tr>';
						$.each(value.lines, function(lindex, lvalue) {
							html += '<tr>';
							html += '<td style="text-align: center;"><a class="log" href="#"" data-date="' + lvalue.date + '">' + lvalue.date + '</a></td>';
							html += '<td style="text-align: center;">' + lvalue.num_requests + '</td>';
							html += '<td style="text-align: center;">' + lvalue.time_elapsed + '</td>';
							html += '<td style="text-align: center;">' + lvalue.size + '</td><td style="text-align: center;">';
							if(typeof value.errors !=='undefined' && typeof value.errors[lvalue.date] !=='undefined') {
								html += '<a class="errlog" href="#" data-date="' + lvalue.date + '" data-errorlog="1">' + value.errors[lvalue.date] + '</a>';
							}
							html += '</td></tr>';
						});
						html += '<tr><td colspan="5">' + value.common + '</td></tr>';
					});
					html += '</table>';
				}
				else if(target == 'test') {
					if(v2) {
					var html = '<table class="table table-striped table-hover table-condensed" style="width: 70%;"><tr><th>Название</th><th style="text-align: center;">Доставка</th><th style="text-align: center;">Сроки</th></tr>';
					} else {
					var html = '<table class="form" style="width: 70%;"><tr><th>Название</th><th style="text-align: center;">Доставка</th><th style="text-align: center;">Сроки</th></tr>';
					}
					$.each(json['data'], function(index, value) {
						html += '<tr><td>' + value.name + '</td><td style="text-align: center;">' + value.ship + ' руб.</td><td style="text-align: center;">' + value.time + ' дн.</td></tr>';
					});
					html += '</table>';
					$('#test').html(html);
				}
				else if(target == 'log') {
					if(json.error) {
						$('#log').empty().html('<div class="error">' + json.error + '</div>');
					}
					else {
						var html = '<pre><h2>' + json.data.head + '</h2>';
						if(file || idate) {
							html += json.data.content;
							html += '</pre>';
						}
						else {
							if(json.data.content) {
								$.each(json.data.content, function(index, value) {
									html += ' <a href="#"" data-file="' + value.datafile + '">' + value.title + '</a> ';
								});
							}
							html += '</pre>';
							$('#log-file').empty();
						}
					}
				}
			}
			$('#' + target).html(html);
		},
		error: function(xhr, ajaxOptions, thrownError) {
			ajaxRequestOnError(xhr, thrownError);
		}
	}); 
}

function update_data(target, buttonObj) {
	var data;

	$.ajax({
		url: 'index.php?route=' + pathFilesModule + '/update_db&target=' + target + '&' + var_token + '=' + token,
		dataType: 'json',
		type: 'get',
		data: data,
		beforeSend: function(jqXHR, settings) {
			$('.block-db' + target + ' .ajximg').append(getImgLoaderAjax());
			$('#content .btn.btn-default, button').attr('disabled', 'disabled');
		},
		complete: function() {
			$('.block-db' + target + ' .ajximg').empty();
			$('#content .btn.btn-default, button').removeAttr('disabled');
		},
		success: function(json) {
			if(json.error) {
				$('.data-info #data-' + target).empty().html('<div class="error">' + json.error + '</div>');
			}
			else {
				$('.data-info #data-' + target).html('<span>' + json.data + '</span>');
			}
		},
		error: function(xhr, ajaxOptions, thrownError) {
			ajaxRequestOnError(xhr, thrownError);
		}
	});
}


function save_license(buttonObj, license = '') {
	var data = {
		license: license
	};
	$.ajax({
		url: 'index.php?route=' + pathFilesModule + '/save_license&' + var_token + '=' + token,
		dataType: 'json',
		type: 'post',
		data: data,
		beforeSend: function(jqXHR, settings) {
			$('.license-block .ajximg').append(getImgLoaderAjax());
			$('#content .btn.btn-default, button, .button').attr('disabled', 'disabled');
		},
		complete: function() {
			$('.license-block .ajximg').empty();
			$('#content .btn.btn-default, button, .button').removeAttr('disabled');
		},
		success: function(json) {
			if(json.error) {
				$('.license-block .rospost_license_input_wrp').append('<div class="error">' + json.error + '</div>');
			}
			else {
				$('.license_state_block_top').html('<span>' + json.data.license_state_text + '</span>');
				$('.license-block .data-info').empty().html('<span>' + json.data.license_state_text + '</span>');
				if(json.data.license_state)
					$('[name="shipping_rospost_license_number"]').attr('readonly', 'readonly');
			}
		},
		error: function(xhr, ajaxOptions, thrownError) {
			ajaxRequestOnError(xhr, thrownError);
		}
	});
}

function export_settings() {
	var data = {};
	$.ajax({
		url: 'index.php?route=' + pathFilesModule + '/export_settings&' + var_token + '=' + token,
		dataType: 'json',
		type: 'post',
		data: data,
		beforeSend: function(jqXHR, settings) {
			$('.block-eiset .ajximg').append(getImgLoaderAjax());
			$('#content .btn.btn-default, button, .button').attr('disabled', 'disabled');
		},
		complete: function() {
			$('.block-eiset .ajximg').empty();
			$('#content .btn.btn-default, button, .button').removeAttr('disabled');
		},
		success: function(json) {
			if(json.error) {
				$('.block-eiset .shipping_rospost_eiset_result').empty().append('<div class="error">' + json.error + '</div>');
			}
			else {
				location.href = json.data;
			}
		},
		error: function(xhr, ajaxOptions, thrownError) {
			ajaxRequestOnError(xhr, thrownError);
		}
	});
}

function import_settings() {
	
	var formData = new FormData();
	formData.append('file_import_rospost', $('#file_import_settings')[0].files[0], $('#file_import_settings')[0].files[0] && $('#file_import_settings')[0].files[0].name);

	var data = {};
	$.ajax({
		url: 'index.php?route=' + pathFilesModule + '/import_settings&' + var_token + '=' + token,
		dataType: 'json',
		type: 'post',
		data: formData,
		processData: false,  // tell jQuery not to process the data
		contentType: false,  // tell jQuery not to set contentType
		beforeSend: function(jqXHR, settings) {
			$('.block-eiset .ajximg').append(getImgLoaderAjax());
			$('#content .btn.btn-default, button, .button').attr('disabled', 'disabled');
		},
		complete: function() {
			$('.block-eiset .ajximg').empty();
			$('#content .btn.btn-default, button, .button').removeAttr('disabled');
		},
		success: function(json) {
			if(json.error) {
				$('.block-eiset .shipping_rospost_eiset_result').empty().append('<div class="error">' + json.error + '</div>');
			}
			else {
				$('.block-eiset .shipping_rospost_eiset_result').empty().append('<div style="color: green;">' + json.data + '</div>');
			}
		},
		error: function(xhr, ajaxOptions, thrownError) {
			ajaxRequestOnError(xhr, thrownError);
		}
	});
}

function handleOnClickCheckLicense(buttonObj) {
	if($(buttonObj).attr('disabled') == 'disabled')
		return false;
	save_license(this, $('[name="shipping_rospost_license_number"]').val());
	return false;
}

function ajaxRequestOnError(xhr, thrownError) {
	// response is too big - error
	/*if(xhr.responseText.length > 500)
		location.href = "/admin/index.php?route=' + pathFilesModule + '&token=' + token + '"
	else
		alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);*/
		console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
}

// only for OC < 2
function image_upload(field, thumb) {
	$('#dialog').remove();
	
	$('#content').prepend('<div id="dialog" style="padding: 3px 0px 0px 0px;"><iframe src="index.php?route=common/filemanager&' + var_token + '=' + token + '&field=' + encodeURIComponent(field) + '" style="padding:0; margin: 0; display: block; width: 100%; height: 100%;" frameborder="no" scrolling="auto"></iframe></div>');
	
	$('#dialog').dialog({
		title: text_image_manager,
		close: function (event, ui) {
			if ($('#' + field).attr('value')) {
				$.ajax({
					url: 'index.php?route=common/filemanager/image&' + var_token + '=' + token + '&image=' + encodeURIComponent($('#' + field).val()),
					dataType: 'text',
					success: function(data) {
						$('#' + thumb).replaceWith('<img src="' + data + '" alt="" id="' + thumb + '" />');
					}
				});
			}
		},	
		bgiframe: false,
		width: 800,
		height: 400,
		resizable: false,
		modal: false
	});
}


function preventDefault(e) {
	return $.isFunction(e.preventDefault) ? e.preventDefault() : false;
}

$(document).ready(function() {

	!license_state && $('a[href="#tab-data"]').trigger('click');

	// only for OC < 2
	$.isFunction($('#tabs a').tabs) && $('#tabs a').tabs();

	if($.isFunction($('html').on)) {
		$('html').on('click', '#save_and_stay', function(e) {
			saveStayAjax(e);
		});

		// handleChangeTypeDeliver
		$('html').on('change', '[type="checkbox"][name="shipping_rospost_type[]"], [type="checkbox"][name="shipping_rospost_type_outside[]"]', function(e) {
			var targetTypeMarkupInput = $('[data-type-textbox-name="' + e.target.value +  '"]').children('input');
			$(e.target).prop('checked') ? targetTypeMarkupInput.removeAttr('disabled') : targetTypeMarkupInput.attr('disabled', 'disabled');
			return preventDefault(e);
		});

		$('html').on('click', '#log a', function(e) {
			get_data('log', $(this).attr('data-file'), false, false);
			return preventDefault(e);
		});
		$('html').on('click', '#stat a.log', function(e) {

			get_data('log', false, $(this).attr('data-date'), false);
			$('#tabs a[href="#tab-log"]').trigger('click')
			return preventDefault(e);
		});
		$('html').on('click', '#stat a.errlog', function(e) {
			get_data('log', false, $(this).attr('data-date'), $(this).attr('data-errorlog'));
			$('#tabs a[href="#tab-log"]').trigger('click');
			return preventDefault(e);
		});

		$('html').on('click', '.image-upload', function(e) {
			var idInput = $(this).siblings('input[type="hidden"]').eq(0).attr('id');
			var idImg = $(this).siblings('img').eq(0).attr('id');
			idInput && idImg && image_upload(idInput, idImg);
			return preventDefault(e);
		});

		$('html').on('click', '.resetImage', function(e) {
			var idImg = $(this).siblings('img').eq(0).attr('id');
			$('#thumb-logo').attr('src', no_image);
			$('#' + idImg).attr('value', '');
			return preventDefault(e);
		});
	}
	else {

		$('html').delegate('#save_and_stay', 'click', function(e) {
			saveStayAjax(e);
		});

		// handleChangeTypeDeliver
		$('html').delegate('[type="checkbox"][name="shipping_rospost_type[]"], [type="checkbox"][name="shipping_rospost_type_outside[]', 'change', function(e) {
			var targetTypeMarkupInput = $('[data-type-textbox-name="' + e.target.value +  '"]').children('input');
			$(e.target).prop('checked') ? targetTypeMarkupInput.removeAttr('disabled') : targetTypeMarkupInput.attr('disabled', 'disabled');
			return false;
		});


		$('html').delegate('#log a', 'click', function(e) {
			get_data('log', $(this).attr('data-file'), false, false);
			return false;
		});
		$('html').delegate('#stat a.log', 'click', function(e) {
			get_data('log', false, $(this).attr('data-date'), false);
			$('#tabs a[href="#tab-log"]').trigger('click');
			return false;
			
		});
		$('html').delegate('#stat a.errlog', 'click', function(e) {
			get_data('log', false, $(this).attr('data-date'), $(this).attr('data-errorlog'));
			$('#tabs a[href="#tab-log"]').trigger('click');
			return false;
		});

		$('html').delegate('.image-upload', 'click', function(e) {
			var idInput = $(this).siblings('input[type="hidden"]').eq(0).attr('id');
			var idImg = $(this).siblings('img').eq(0).attr('id');
			idInput && idImg && image_upload(idInput, idImg);
			return false;
		});

		$('html').delegate('.resetImage', 'click', function(e) {
			var idImg = $(this).siblings('img').eq(0).attr('id');
			$('#thumb-logo').attr('src', no_image);
			$('#' + idImg).attr('value', '');
			return false;
		});

	}

});