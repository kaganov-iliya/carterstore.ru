<?php
/**
 * @author Larionov Alexandr
 * @link   http://larionov.me
 */

class ModelShippingRospost extends Model {

	// version Opencart 2
	private $v2;
	// version Opencart 3
	private $v3;

	public function __construct ($registry) {
		parent::__construct($registry);
		$this->v2 = version_compare(VERSION, '2.0.0.0', '>=');
		$this->v3 = version_compare(VERSION, '3.0.0', '>=');
	}

	// install / update
	public function install($filep = false) {
		$file = !$filep ? DIR_APPLICATION . '../tmp/postcalc_light_sql/postcalc_light.sql' : $filep;

		if (!file_exists($file)) {
			exit('Could not load sql file: ' . $file . '. Place the file in the specified path.');
		}

		$lines = file($file);

		if ($lines) {
			$sql = '';

			foreach($lines as $line) {
				if ($line && (substr($line, 0, 2) != '--') && (substr($line, 0, 1) != '#')) {
					$sql .= $line;

					if (preg_match('/;\s*$/', $line)) {
						$sql = str_replace("DROP TABLE IF EXISTS `", "DROP TABLE IF EXISTS `" . DB_PREFIX, $sql);
						$sql = str_replace("CREATE TABLE `", "CREATE TABLE `" . DB_PREFIX, $sql);
						$sql = str_replace("LOCK TABLES `", "LOCK TABLES `" . DB_PREFIX, $sql);
						$sql = str_replace("INSERT INTO `", "INSERT INTO `" . DB_PREFIX, $sql);
						$sql = str_replace("ALTER TABLE `", "ALTER TABLE `" . DB_PREFIX, $sql);

						$this->db->query($sql);

						$sql = '';
					}
				}
			}
			if($this->v2) {
				$this->addModification();
			}
		}
		else {
			exit('Could not load sql file: ' . $file . '. Check the file in the specified path.');
		}


	}
	public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "postcalc_light_cities`;");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "postcalc_light_post_indexes`;");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "postcalc_light_countries`;");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "postcalc_subjects`;");

		if($this->v2) {
			$this->deleteModification();
		}
	}

	// FOR OLD VERSION: remove old tables without prefix. is deprecated in newest version
	public function deleteTablesWithoutPrefix() {
		if(DB_PREFIX != '') {
			$this->db->query("DROP TABLE IF EXISTS `" . "postcalc_light_cities`;");
			$this->db->query("DROP TABLE IF EXISTS `" . "postcalc_light_post_indexes`;");
			$this->db->query("DROP TABLE IF EXISTS `" . "postcalc_light_countries`;");
		}
	}

	public function updateDBFTables($file) {

		if(!file_exists($file))
			exit($file . ' is not exists.');
		// load lib xbase
		if(method_exists($this->load, 'library')) {
			$this->load->library('xbase/XBaseTable');
		}
		else
			if(!class_exists('XBase\XBaseTable') || !class_exists('XBase\Record') || !class_exists('XBase\Column'))
				require_once DIR_SYSTEM . 'library/xbase/XBaseTable.php';
		if(!class_exists('XBase\XBaseTable') || !class_exists('XBase\Record') || !class_exists('XBase\Column'))
			exit("can't load library xbase");
		$table = new XBase\XBaseTable($this->registry);
		$table->init($file, array('index', 'region', 'city', 'autonom'), 'CP866');

		$db_values = '';
		while ($record = $table->nextRecord()) {
			$db_values .= "('" . $record->index . "', '" . $record->region . "', '" . $record->city . "', '" . $record->autonom . "'), ";
		}

		// drop old tables
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "postcalc_subjects`");

		// create table
		$this->db->query("CREATE TABLE `" . DB_PREFIX . "postcalc_subjects` (
							`pindex` char(6) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
							`region` varchar(100) NOT NULL DEFAULT '',
							`city` varchar(100) NOT NULL DEFAULT '',
							`autonom` varchar(100) NOT NULL DEFAULT '',
							PRIMARY KEY (`pindex`,`city`)
						) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='На базе эталонного справочника PIndx, версия 01 от *********'");

		$values = '';
		$sql = 'INSERT INTO `' . DB_PREFIX . 'postcalc_subjects` (`pindex`, `region`, `city`, `autonom`) VALUES ' . preg_replace('/, $/', '', $db_values);

		$this->db->query('LOCK TABLES `' . DB_PREFIX . 'postcalc_subjects` WRITE');
		$this->db->query($sql);
		$this->db->query('UNLOCK TABLES');
	}

	public function getInsidePosts() {
		return $this->inside_posts;
	}

	public function getOutsidePosts() {
		return $this->outside_posts;
	}

	public function editSettingValue($code = '', $key = '', $value = '', $store_id = 0) {

		if($this->v2)
			$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE store_id = '" . (int)$store_id . "' AND `code` = '" . $this->db->escape($code) . "' AND `key` = '" . $this->db->escape($key) . "'");
		else
			$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE store_id = '" . (int)$store_id . "' AND `group` = '" . $this->db->escape($code) . "' AND `key` = '" . $this->db->escape($key) . "'");
		if (substr($key, 0, strlen($code)) == $code) {
			if (!is_array($value)) {
				if($this->v2)
					$this->db->query("INSERT INTO " . DB_PREFIX . "setting SET store_id = '" . (int)$store_id . "', `code` = '" . $this->db->escape($code) . "', `key` = '" . $this->db->escape($key) . "', `value` = '" . $this->db->escape($value) . "'");
				else
					$this->db->query("INSERT INTO " . DB_PREFIX . "setting SET store_id = '" . (int)$store_id . "', `group` = '" . $this->db->escape($code) . "', `key` = '" . $this->db->escape($key) . "', `value` = '" . $this->db->escape($value) . "'");
			}
		}
	}

	private function isExistModificationRospost() {
		if($this->v3) {
			$this->load->model('setting/modification');
			$model_modification = 'model_setting_modification';
		} else {
			$this->load->model('extension/modification');
			$model_modification = 'model_extension_modification';
		}

		$modificationCode = 'rospost shipping method';
		$modification = false;
		$modificationId = false;

		if(method_exists($this->$model_modification, 'getModificationByCode')) {
			$modification = $this->$model_modification->getModificationByCode($modificationCode);
		}
		else {
			$modifications = $this->$model_modification->getModifications();
			if(!empty($modifications)) {
				foreach($modifications as $v) {
					if($v['code'] == $modificationCode) {
						$modificationId = $v['modification_id'];
						break;
					}
				}
				$modification = $modificationId !== false ? $this->$model_modification->getModification($modificationId) : false;
			}
		}

		return array(
			'stateModification' => $modification['modification_id'],
			'model_modification' => $this->$model_modification,
		);
	}

	public function deleteModification() {
		$isExistModificationRospost = $this->isExistModificationRospost();

		if (!empty($isExistModificationRospost['stateModification'])) {
			$isExistModificationRospost['model_modification']->deleteModification($isExistModificationRospost['stateModification']);
		}

	}

	public function getInstalledExtensionIDByCode($type, $code) {
		$extension_data = array();
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "extension` WHERE `type` = '" . $this->db->escape($type) . "' and `code` = '" . $this->db->escape($code) . "'");

		return count($query->rows) == 1 ? $query->rows[0]['extension_id'] : 0;
	}

	// add modification ocmod
	public function addModification() {
		//return;

		$file_config_default = DIR_CONFIG . 'default' . '.php';

		if (file_exists($file_config_default)) {
			// get settings from sys/config file
			$this->load->config('default');
			
			// add ocmod for twig in OC v3
			if($this->v3 && $this->config->get('template_engine') == 'twig') {

				$isExistModificationRospost = $this->isExistModificationRospost();

				$extension_install_id = ($ext_id = $this->getInstalledExtensionIDByCode('shipping', 'rospost')) !== false ? $ext_id : 0;


				if (empty($isExistModificationRospost['stateModification'])) {
					$isExistModificationRospost['model_modification']->addModification(array(
						'extension_install_id' => $extension_install_id, // for OC >= 3
						'code' => 'rospost shipping method',
						'name' => 'rospost shipping method',
						'author' => 'larionov_a (a@larionov.me)',
						'version' => '1.1',
						'link' => 'http://larionov.me',
						'xml' => '
						<modification>
							<code>rospost shipping method</code>
							<name>rospost shipping method</name>
							<version>1.1</version>
							<author>larionov_a (a@larionov.me)</author>
							<link>http://larionov.me</link>
							  <file path="system/library/template/twig.php">
								<operation>
							      <search>
							        <![CDATA[$this->twig = new \Twig_Environment($loader, $config);]]>
							      </search>
							      <add position="replace">
							        <![CDATA[
									// debug
							        $config[\'debug\'] = true;
									$this->twig = new \Twig_Environment($loader, $config);
									$this->twig->addExtension(new \Twig_Extension_StringLoader());
									// debug
									$this->twig->addExtension(new \Twig_Extension_Debug());
									]]>
							      </add>
							    </operation>
							  </file> 
							</modification>',
						'status' => 1
					));
				}
			}
		}
	}
}

class ModelExtensionShippingRospost extends ModelShippingRospost {
}