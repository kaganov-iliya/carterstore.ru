<?php
/**
 * @author Larionov Alexandr
 * @link   http://larionov.me
 */

$_['rospost_settings_fields'] = array (
		'allow_detail_types' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'allow_detail_title' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'allow_in_region' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'allow_int_deliver' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'allow_part_package' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'allow_restrict_notify' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'append_cod_to_total' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
				'text_append_cod_to_total' => '2',
			),
		),
		'cache_dir' => array(
			'type' => 'text',
			'status_value' => 'default', // required
			'value' => 'system/storage/cache',  // required
			'validation_isRequired' => true,
			'validation_status' => true,
			'condition' => 'exists',
			'input_group' => array (
				'before' => $_SERVER['DOCUMENT_ROOT'] . '/',
				'after' => '/',
			),
		),
		'cache_valid' => array(
			'type' => 'text',
			'status_value' => 'default', // required
			'value' => '600',  // required
		),
		'city_as_pindex' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
			'in_query_postcalc' => true,
		),
		'cs' => array(
			'type' => 'select',
			'data' => array(
				'entry_cs_text_win' => 'windows-1251',
				'entry_cs_text_utf' => 'utf-8',
			),
			'status_value' => 'fixed', // required
			'value' => 'utf-8', // required
			'in_query_postcalc' => true,
		), // encode
		'cost' => array(
			'type' => 'text',
			'validation_isRequired' => false,
			'validation_status' => true,
			'condition' => 'regexp',
			'regexp' => '/^[0-9\.\,]+$/',
		),
		'default_from' => array(
			'type' => 'text',
			'in_query_postcalc' => true,
			'validation_isRequired' => true,
			'validation_status' => true,
			'condition' => 'exists'
		),
		'default_weight' => array(
			'type' => 'radio',
			'data' => array(
				'error_default_weight_always' => '1',
				'error_default_weight_never' => '0',
				'error_default_weight_if_empty_card' => '2',
			),
			'extra_date' => array (
				'type' => 'text',
				'validation_isRequired' => true,
				'validation_status' => true,
				'condition' => 'exists'
			),
			'in_query_postcalc' => true,
			'validation_isRequired' => false,
			'validation_status' => true,
			'condition' => 'ignore',
		),
		'd' => array(
			'type' => 'text', // ! check
			//'validation_status' => true,
			//'condition' => 'regexp',
			//'regexp' => '',
			'in_query_postcalc' => true,
		), // date
		'discount' => array(
			'type' => 'text',
			'validation_isRequired' => false,
			'validation_status' => true,
			'condition' => 'ignore', // checks in controller
		),
		'error_log' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'error_log_send' => array(
			'type' => 'text',
			'status_value' => 'default', // required
			'value' => '10',  // required
		),
		'increase_time_shipping' => array (
			'type' => 'textbox',
			'data' => array(),
			'data_source_name' => 'inside_post', // name array in template from controller
			'data_source_keys' => array (
				'label' => 'title', // if only label - value is key in array
			),
			'check_exists_source_name' => 'type', // Массив, в котором необходимо проверить наличие ключа из данного поля
			'validation_isRequired' => false,
		),
		'license_number' => array (),
		'limit_total_sum_for_type' => array (
			'type' => 'textbox',
			'data' => array(),
			'data_source_name' => 'inside_post', // name array in template from controller
			'data_source_keys' => array (
				'label' => 'title', // if only label - value is key in array
			),
			'check_exists_source_name' => 'type', // Массив, в котором необходимо проверить наличие ключа из данного поля
			'validation_isRequired' => false,
		),
		'limit_total_shipping_free' => array (
			'type' => 'textbox',
			'data' => array(),
			'data_source_name' => 'inside_post', // name array in template from controller
			'data_source_keys' => array (
				'label' => 'title', // if only label - value is key in array
			),
			'check_exists_source_name' => 'type', // Массив, в котором необходимо проверить наличие ключа из данного поля
			'validation_isRequired' => false,
		),
		'limit_total_shipping' => array (
			'type' => 'text',
			'status_value' => 'default', // required
			'value' => '0',  // required
		),
		'limit_total_weight_for_type' => array (
			'type' => 'textbox',
			'data' => array(),
			'data_source_name' => 'inside_post', // name array in template from controller
			'data_source_keys' => array (
				'label' => 'title', // if only label - value is key in array
			),
			'check_exists_source_name' => 'type', // Массив, в котором необходимо проверить наличие ключа из данного поля
			'validation_isRequired' => false,
		),
		'limit_total_weight_for_type_int' => array (
			'type' => 'textbox',
			'data' => array(),
			'data_source_name' => 'outside_post', // name array in template from controller
			'data_source_keys' => array (
				'label' => 'title', // if only label - value is key in array
			),
			'check_exists_source_name' => 'type_outside', // Массив, в котором необходимо проверить наличие ключа из данного поля
			'validation_isRequired' => false,
		),
		'markup_of_type' => array (
			'type' => 'textbox',
			'data' => array(),
			'data_source_name' => 'inside_post', // name array in template from controller
			'data_source_keys' => array (
				'label' => 'title', // if only label - value is key in array
			),
			'check_exists_source_name' => 'type', // Массив, в котором необходимо проверить наличие ключа из данного поля
			'validation_isRequired' => false,
		),
		'markup_of_type_int' => array (
			'type' => 'textbox',
			'data' => array (),
			'data_source_name' => 'outside_post', // name array in template from controller
			'data_source_keys' => array (
				'label' => 'title', // if only label - value is key in array
			),
			'check_exists_source_name' => 'type_outside', // Массив, в котором необходимо проверить наличие ключа из данного поля
			'validation_isRequired' => false,
		),
		'ml' => array(
			'type' => 'text',
			'in_query_postcalc' => true,
			'status_value' => 'fixed', // required
			'value' => $this->get('config_email'), // required
			'validation_isRequired' => true,
			'validation_status' => true,
			'condition' => 'exists'
		), // mail
		'name' => array(
			'validation_isRequired' => true,
			'validation_status' => true,
			'condition' => 'exists',
			'type' => 'text',
		),
		'hide_from' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'hide_to' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'ib' => array(
			'in_query_postcalc' => true,
			'type' => 'select',
			'data' => array(
				'entry_ib_text_full' => 'f',
				'entry_ib_text_part' => 'p',
			),
			'add2Label' => '(<a href="http://postcalc.ru/faq.html#insurance" target="_blank">подробнее</a>)',
		), // insurance
		'ico_type' => array (
			'type' => 'source',
			'vars_printf' => array (
				'shipping_rospost_ico_type_src',
				'shipping_rospost_ico_type_placeholder',
				'shipping_rospost_ico_type',
				'text_browse', // for < OC2
				'text_clear',
			),
			'data' => array (
				'tpl' => '
					<a
						href=""
						id="thumb-ico"
						data-toggle="image"
						class="img-thumbnail"
					>
						<img
							src="%s"
							alt=""
							title=""
							data-placeholder="%s"
							/>
					</a>
					<input
						type="hidden"
						name="shipping_rospost_ico_type"
						value="%s"
						id="shipping_rospost_ico_type"
					/>
				',
				'tplLessV2' => '
					<div class="image">
						<img
							src="%s"
							alt=""
							id="thumb-logo"
							data-placeholder="%s"
						/>
						<input
							type="hidden"
							name="shipping_rospost_ico_type"
							value="%s"
							id="shipping_rospost_ico_type"
						/>
						<br />
						<a class="image-upload">
							%s
						</a>
						&nbsp;&nbsp;|&nbsp;&nbsp;
						<a class="resetImage">
							%s
						</a>
					</div>
				',
				'twig' => '
					<a
						href=""
						id="thumb-ico"
						data-toggle="image"
						class="img-thumbnail"
					>
						<img
							src="{{ shipping_rospost_ico_type_src }}"
							alt=""
							title=""
							data-placeholder="{{ shipping_rospost_ico_type_placeholder }}"
						/>
					</a>
					<input
						type="hidden"
						name="shipping_rospost_ico_type"
						value="{{ shipping_rospost_ico_type }}"
						id="shipping_rospost_ico_type"
					/>
				',
			),
			'exclude' => false, // not process for output form in controller - array DATA
		),
		'ico_size' => array(),
		'ico_pos' => array(
			'type' => 'radio',
			'data' => array(
				'text_ico_before' => '1',
				'text_ico_after' => '0',
			),
		),
		'only_costtype' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'pr' => array(
			'type' => 'text',
			'in_query_postcalc' => true,
		), // Наценка в рублях за обработку заказа
		'pk' => array(
			'type' => 'text',
			'in_query_postcalc' => true,
		), // Наценка в рублях за упаковку одного отправления
		//'autocomplete_items' => array(),
		'log' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'r' => array(
			'type' => 'text',
			'in_query_postcalc' => true,
		), // round
		'rate' => array(
			'type' => 'textarea',
		),
		'send_cost_in_request' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'servers' => array(
			'type' => 'textarea',
			'status_value' => 'default', // required
			'value' => 'test.postcalc.ru',  // required
			'in_query_postcalc' => true,
			'validation_isRequired' => true,
			'validation_status' => true,
			'condition' => 'exists'
		),
		'show_cost_deliver' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'show_time' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'show_cod' => array(
			'type' => 'radio',
			'data' => array(
				'text_yes' => '1',
				'text_no' => '0',
			),
		),
		'source' => array (
			'type' => 'text',
			'status_value' => 'fixed', // required
			'value' => 'mysql', // required
			'validation_isRequired' => true,
			'validation_status' => true,
			'condition' => 'exists'
			),
		'st' => array(
			'type' => 'text',
			'in_query_postcalc' => true,
			'status_value' => 'fixed', // required
			'value' => $_SERVER['HTTP_HOST'], // required
			'validation_isRequired' => true,
			'validation_status' => true,
			'condition' => 'exists',
		), // site
		'status' => array(
			'type' => 'select',
			'data' => array(
				'text_enabled' => '1',
				'text_disabled' => '0',
			),
		),
		'store' => array(
			'type' => 'checkbox',
			'data' => array(
				'text_default' => '0',
			),
			'data_source_name' => 'stores', // name array in template from controller
			'data_source_keys' => array (
				'value' => 'store_id',
				'label' => 'name',
			),
		),
		'sort_order' => array(
			'type' => 'text',
		),
		'text_message' => array(
			'type' => 'textarea',
		),
		'text_limit_total_shipping' => array (
			'type' => 'textarea',
		),
		'type' => array(
			'type' => 'checkbox',
			'data' => array(),
			'data_source_name' => 'inside_post', // name array in template from controller
			'data_source_keys' => array (
				'label' => 'title', // if only label - value is key in array
			),
		),
		'type_outside' => array(
			'type' => 'checkbox',
			'data' => array(),
			'data_source_name' => 'outside_post', // name array in template from controller
			'data_source_keys' => array (
				'label' => 'title', // if only label - value is key in array
			),
		),
		'timeout' => array(
			'type' => 'text',
			'status_value' => 'default', // required
			'value' => '5',  // required
		),
		'version_module' => array(),
		'weight_class_gramm' => array(
			'type' => 'select',
			'data_source_name' => 'weight_classes', // name array in template from controller
			'data_source_keys' => array (
				'value' => 'weight_class_id',
				'label' => 'title',
			),
			'data' => array(),
			'in_query_postcalc' => true,
		), // gramm id settings

);


// tab options
$_['rospost_settings_blocks'] = array (
	'text_options_common' => array(
		'name',
		'store',
		'status',
		'sort_order',
	),
	'text_options_calc_view' => array(
		'weight_class_gramm',
		'ib',
		'r',
		'pr',
		'pk',
		'cost',
		'limit_total_shipping_free',
		'limit_total_shipping',
		'text_limit_total_shipping',
		'markup_of_type',
		'markup_of_type_int',
		'discount',
		'rate',
		'increase_time_shipping',
		'default_weight',
		'allow_in_region',
		'allow_int_deliver',
		'only_costtype',
		'hide_from',
		'hide_to',
		'allow_detail_title',
		'allow_detail_types',
		'show_time',
		'show_cod',
		'show_cost_deliver',
		'append_cod_to_total',
		'send_cost_in_request',
		'allow_part_package',
		'allow_restrict_notify',
		'ico_type',
		'ico_pos',
		'text_message',
	),
	'text_options_postcalc' => array(
		'type',
		'limit_total_sum_for_type',
		'limit_total_weight_for_type',
		'type_outside',
		'limit_total_weight_for_type_int',
		'source',
		'st',
		'ml',
		'cs',
		'd',
		'default_from',
		'log',
		'error_log',
		'error_log_send',
		'cache_dir',
		'cache_valid',
		'timeout',
		'servers',
		'city_as_pindex',
	),
);

$_['rospost_language_common_data'] = array (
		'heading_title',
		'text_edit_rospost',
		'text_enabled',
		'text_disabled',
		'text_all_zones',
		'text_none',
		'text_select_all',
		'text_unselect_all',
		'text_options_common',
		'text_options_calc_view',
		'text_options_postcalc',
		'text_postcalc_copy',
		'tab_option',
		'tab_history',
		'tab_server',
		'tab_log',
		'tab_data',
		'tab_general',
		'text_get_stat',
		'text_get_test',
		'text_get_log',
		'text_get_log',
		'text_update_data_postcalc',
		'text_update_data_rospost',
		'text_update_data_license',
		'text_stat_postcalc',
		'text_test_postcalc',
		'text_test_postcalc_etc',
		'text_log_postcalc',
		'text_tab_data',
		'desc_tab_data_postcalc',
		'desc_tab_data_rospost',
		'desc_tab_data_license',
		'desc_tab_import_export',
		'text_block_data_postcalc',
		'text_block_data_rospost',
		'text_block_data_license',
		'text_block_data_export_import_settings',
		'text_export_settings',
		'text_import_settings',

		'text_all_types',
		'text_append_cod_to_total',
		'text_ico_before',
		'text_ico_after',

		'entry_license_number',
		'entry_license_number_tooltip',

		'entry_name',
		'entry_name_tooltip',
		'entry_cost',
		'entry_cost_tooltip',
		'entry_discount',
		'entry_discount_tooltip',
		'entry_rate',
		'entry_rate_tooltip',

		'entry_weight_class_gramm',
		'entry_weight_class_gramm_tooltip',

		'entry_limit_total_shipping_free',
		'entry_limit_total_shipping_free_tooltip',

		'entry_limit_total_shipping',
		'entry_limit_total_shipping_tooltip',

		'entry_increase_time_shipping',
		'entry_increase_time_shipping_tooltip',

		'entry_source',
		'entry_source_tooltip',
		'entry_st',
		'entry_st_tooltip',
		'entry_ml',
		'entry_ml_tooltip',
		'entry_ib',
		'entry_ib_tooltip',
		'entry_ib_text_full',
		'entry_ib_text_part',
		'entry_r',
		'entry_r_tooltip',
		'entry_pr',
		'entry_pr_tooltip',
		'entry_pk',
		'entry_pk_tooltip',
		'entry_cs',
		'entry_cs_tooltip',
		'entry_cs_text_utf',
		'entry_cs_text_win',
		'entry_d',
		'entry_d_tooltip',
		'entry_default_from',
		'entry_default_from_tooltip',
		'entry_default_weight',
		'entry_default_weight_tooltip',
		'entry_allow_in_region',
		'entry_allow_in_region_tooltip',
		'entry_allow_int_deliver',
		'entry_allow_int_deliver_tooltip',
		'entry_hide_from',
		'entry_hide_from_tooltip',
		'entry_hide_to',
		'entry_hide_to_tooltip',
		'entry_log',
		'entry_log_tooltip',
		'entry_error_log',
		'entry_error_log_tooltip',
		'entry_error_log_send',
		'entry_error_log_send_tooltip',
		'entry_cache_dir',
		'entry_cache_dir_tooltip',
		'entry_cache_valid',
		'entry_cache_valid_tooltip',
		'entry_timeout',
		'entry_timeout_tooltip',
		'entry_servers',
		'entry_servers_tooltip',
		'entry_city_as_pindex',
		'entry_city_as_pindex_tooltip',
		'entry_allow_part_package',
		'entry_allow_part_package_tooltip',
		'entry_allow_restrict_notify',
		'entry_allow_restrict_notify_tooltip',
		'entry_allow_detail_title',
		'entry_allow_detail_title_tooltip',
		'entry_allow_detail_types',
		'entry_allow_detail_types_tooltip',
		'entry_ico_type',
		'entry_ico_type_tooltip',
		'entry_ico_pos',
		'entry_ico_pos_tooltip',
		'entry_text_message',
		'entry_text_message_tooltip',

		'entry_show_time',
		'entry_show_time_tooltip',
		'entry_show_cod',
		'entry_show_cod_tooltip',
		'entry_append_cod_to_total',
		'entry_append_cod_to_total_tooltip',
		'entry_send_cost_in_request',
		'entry_send_cost_in_request_tooltip',
		'entry_markup_of_type',
		'entry_markup_of_type_tooltip',

		'entry_markup_of_type_int',
		'entry_markup_of_type_int_tooltip',

		'entry_type',
		'entry_type_tooltip',
		'entry_type_outside',
		'entry_type_outside_tooltip',
		'entry_only_costtype',
		'entry_only_costtype_tooltip',

		'entry_status',
		'entry_sort_order',
		'entry_store',
		'entry_store_tooltip',

		'entry_text_license',
		'entry_text_license_tooltip',

		'list_faq',

		'copyright',
		
		'text_yes',
		'text_no',
		'button_save',
		'button_save_and_stay',
		'button_cancel',
		'error_field',

		'text_default',
		'text_image_manager',
		'text_browse',
		'text_clear',
		'error_default_weight_never',
		'error_default_weight_always',
		'error_default_weight_if_empty_card',

		'error_field_common',
		'error_saved',
		'success_saved',

);

?>